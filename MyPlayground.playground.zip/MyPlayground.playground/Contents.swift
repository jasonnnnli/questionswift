import UIKit

var greeting = "Hello, playground"
var array = [1,2,5,4]


    var i = 1
    while i < array.count {
        let x = array[i]
        var j = i - 1
        while j >= 0 && array[j] > x {
            array[j+1] = array[j]
            j -= 1
        }
        array[j+1] = x
        i += 1
    }
    print(array)
var text = ["a","t","t","a"]
var reversedText = Array(text.reversed())
if text == reversedText {
  print("\(text) is a Palindrome!")
 }
  else {
    print("\(text) is a Palindrome!")
}
